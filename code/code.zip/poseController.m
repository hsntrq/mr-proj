function poseController(xg, yg, thetag, connection, parameters)
% Pose controller for a wheeled robot
% (xg,yg): Desired goal position
% thetag: Desired orientation
% parameters: Contain stopping conditions

EndCond = 0;
while (~EndCond)    
    % Get Current pose from vrep
    [x, y, theta] = bob_getPose(connection);
    
    % Computing control commands v and w
    % Write your code here
    
    % Controller Gain
    K1 = 0.5;
    K2 = 0.5;
%     thetag = atan((yg-y)/(xg-x));

    %Calculating Difference and Error angle
    D = sqrt((xg - x)^2 + (yg - y)^2) * sign(cos(thetag));
    e = thetag - theta;
    % e = wrapToPi(e);

    % Pose Correction
    if (D < 0.03)
    w = K1 * atan2(sin(e),cos(e)) * sign(cos(thetag));
    v= 0;

    % Straight-line motion
    else
    % w = K1 * atan2(sin(e),cos(e)) * sign(cos(thetag));
    w = 0;
    v = K2 * D;
    end
% Calculate wheel speeds
    [LeftWheelVelocity, RightWheelVelocity ] = calculateWheelSpeeds(v, w, parameters);

    % End condition
    dtheta = abs(normalizeAngle(theta-thetag));
    rho = sqrt((abs(xg)-abs(x))^2+(abs(yg)-abs(y))^2);  

    EndCond = (rho < parameters.dist_threshold && dtheta < parameters.angle_threshold);   
    
    % Set robot wheel speeds
    bob_setWheelSpeeds(connection, LeftWheelVelocity, RightWheelVelocity);
end

% Stopping Bob
bob_setWheelSpeeds(connection, 0,0);